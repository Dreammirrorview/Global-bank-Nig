# Global Bank - Complete Banking Wallet System

**Owned by: Olawale Abdul-ganiyu**

## 🏦 Overview

Global Bank is a comprehensive digital banking wallet system with advanced features including cryptocurrency-style wallet mining, real-time transactions, and complete admin management capabilities.

## ✨ Key Features

### 💰 Wallet Mining System
- **Automatic Mining**: Every 5 minutes, each active wallet generates ₦150,000
- **Real-Time Tracking**: Live countdown timer shows next mining reward
- **Transaction Recording**: All mining activities are logged and tracked

### 🔄 Transaction Management
- **Send Money**: Transfer funds to any bank account (internal or external)
- **Receive Money**: Generate account numbers (1-10 digits) to receive payments
- **Transaction History**: Complete record of all transactions with details
- **Real-Time Updates**: Balance updates immediately after transactions

### 👤 User Management
- **Account Creation**: Admin can create unlimited user accounts
- **Unique Account Numbers**: Generated 1-10 digit account numbers
- **Wallet Addresses**: Unique wallet addresses for each user
- **Account Status**: Admin can activate/deactivate user accounts

### 🔐 Admin Dashboard
- **Secure Login**: Protected admin access with JWT authentication
- **User Overview**: View all users with balances and status
- **Credit/Debit**: Admin can manually credit or debit any account
- **Activity Logs**: Complete audit trail of all system activities
- **Statistics**: Real-time dashboard with total users and balances

### 📧 Notification System
- **Email Alerts**: Automatic email notifications for all transactions
- **Transaction Confirmations**: Send receipts for all transfers
- **Account Updates**: Notifications for account changes

### 📋 Transaction Features
Each transaction includes:
- Transaction ID
- Date and Time
- Transaction Type (Credit/Debit/Mining/Transfer)
- Amount
- Sender Account & Name
- Receiver Account & Name
- Bank Name
- Wallet Address
- Description
- Status

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- Python 3 (for frontend server)
- Modern web browser

### Installation

1. **Navigate to the backend directory:**
   ```bash
   cd global-bank/backend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start the backend server:**
   ```bash
   node server.js
   ```
   The backend will run on `http://localhost:3000`

4. **Start the frontend server:**
   ```bash
   cd ../frontend
   python3 -m http.server 8081
   ```
   The frontend will run on `http://localhost:8081`

5. **Access the application:**
   Open your browser and navigate to `http://localhost:8081`

## 🔑 Default Admin Credentials

- **Username:** `admin`
- **Password:** `admi`

⚠️ **Important:** Change these credentials in production!

## 📁 Project Structure

```
global-bank/
├── backend/
│   ├── server.js           # Main Express server
│   ├── database.js         # SQLite database configuration
│   ├── package.json        # Node.js dependencies
│   └── globalbank.db       # SQLite database (auto-created)
├── frontend/
│   ├── index.html          # Main HTML file
│   ├── css/
│   │   └── style.css       # Styling
│   └── js/
│       └── app.js          # Frontend JavaScript
└── legal-docs/
    ├── terms-of-service.html
    ├── privacy-policy.html
    └── disclaimer.html
```

## 🛠️ Technical Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **SQLite** - Database
- **JWT** - Authentication
- **bcryptjs** - Password hashing
- **node-cron** - Scheduled tasks (mining)
- **nodemailer** - Email notifications

### Frontend
- **HTML5** - Structure
- **CSS3** - Styling with modern gradients
- **Vanilla JavaScript** - No frameworks, pure JS
- **Fetch API** - API communication

## 🔒 Security Features

- **Password Hashing**: All passwords are hashed using bcrypt
- **JWT Authentication**: Secure token-based authentication
- **CORS Protection**: Cross-origin resource sharing configured
- **Input Validation**: Server-side validation for all inputs
- **SQL Injection Protection**: Parameterized queries
- **Activity Logging**: All admin actions are logged

## ⛏️ Mining System Details

The wallet mining system automatically rewards active users:

- **Reward Amount**: ₦150,000 per mining cycle
- **Mining Interval**: Every 5 minutes
- **Eligibility**: Only active users receive rewards
- **Transaction Recording**: Each mining event creates a transaction record
- **Email Notification**: Users receive email notifications for mining rewards

## 📊 Admin Capabilities

Admin users can:
1. **Create User Accounts** - Generate new accounts with unique details
2. **View All Users** - Complete list with balances and status
3. **Credit Accounts** - Add funds to any user account
4. **Debit Accounts** - Remove funds from any user account
5. **Activate/Deactivate Users** - Control user access
6. **View Transactions** - See all system transactions
7. **View Activity Logs** - Complete audit trail
8. **Access User Wallets** - View individual user details and transactions

## 🔄 Transaction Flow

### Sending Money
1. User enters sender account number
2. User enters receiver account number
3. User selects bank (optional for internal transfers)
4. User enters amount and description
5. System validates balance
6. Transaction is processed
7. Both sender and receiver receive notifications
8. Transaction is recorded in history

### Mining Rewards
1. System runs every 5 minutes
2. Identifies all active users
3. Generates ₦150,000 for each user
4. Updates user balance
5. Creates transaction record
6. Sends email notification
7. Updates activity logs

## 📧 Email Configuration

To enable email notifications, update the transporter configuration in `server.js`:

```javascript
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com',
    pass: 'your-app-password' // Use app-specific password
  }
});
```

## 📄 Legal Documents

The application includes comprehensive legal documentation:

1. **Terms of Service** - Complete terms for using the platform
2. **Privacy Policy** - Data handling and user privacy
3. **Legal Disclaimer** - Risk warnings and liability limitations

All legal documents are located in the `legal-docs/` directory.

## 🎨 UI/UX Features

- **Modern Design**: Beautiful gradient-based UI
- **Responsive**: Works on desktop and mobile devices
- **Real-Time Updates**: Live balance and transaction updates
- **Dashboard Analytics**: Visual statistics and metrics
- **Easy Navigation**: Intuitive sidebar menu
- **Modal Dialogs**: Clean popup forms for actions
- **Status Badges**: Visual indicators for account status

## 🔧 Configuration

### Backend Port
Default port is `3000`. Change in `server.js`:
```javascript
const PORT = process.env.PORT || 3000;
```

### Database
SQLite database is auto-created as `globalbank.db` in the backend directory.

### JWT Secret
Change the JWT secret in `server.js` for production:
```javascript
const JWT_SECRET = 'your-secret-key-here';
```

## 🐛 Troubleshooting

### Server won't start
- Check if port 3000 is already in use
- Verify Node.js is installed correctly
- Run `npm install` to ensure all dependencies are installed

### Database errors
- Delete `globalbank.db` and restart the server
- Check file permissions in the backend directory

### Email not working
- Verify Gmail app password is correct
- Check firewall settings
- Ensure nodemailer is properly configured

## 📞 Support

For support or questions:
- **Email**: support@globalbank.com
- **Owner**: Olawale Abdul-ganiyu
- **Phone**: +234 800 000 0000

## 📝 License

© 2024 Global Bank. All Rights Reserved.
Owned by Olawale Abdul-ganiyu

---

## 🎉 You're Ready!

Your Global Bank application is now running! Access it at the exposed URL and start managing your digital banking operations.

**Important Notes:**
- This is a demonstration system
- In production, use real banking APIs for external transfers
- Implement proper security measures for production deployment
- Regularly backup the database
- Monitor system logs for unusual activity